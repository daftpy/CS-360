package com.zybooks.weighttrackapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    // Database name
    private static final String DATABASE_NAME = "weighttrack.db";
    // Database version
    private static final int DATABASE_VERSION = 3;
    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    // Table names

    private static final String TABLE_USERS = "users";
    private static final String TABLE_WEIGHT = "weight";
    private static final String TABLE_GOAL = "goal";

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Create the user table
        String CREATE_USERS_TABLE = "CREATE TABLE " + TABLE_USERS + "(" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "username TEXT UNIQUE," +
                "password TEXT)";
        db.execSQL(CREATE_USERS_TABLE);

        // Create the weight records table
        String CREATE_WEIGHT_TABLE = "CREATE TABLE " + TABLE_WEIGHT + "(" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "weight REAL," +
                "date TEXT)";
        db.execSQL(CREATE_WEIGHT_TABLE);

        // Create the table for the goal record
        String CREATE_GOAL_TABLE = "CREATE TABLE " + TABLE_GOAL + "(" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "target_weight REAL)";
        db.execSQL(CREATE_GOAL_TABLE);
    }

    // Update the tables there is a new schema
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS users");
        db.execSQL("DROP TABLE IF EXISTS weight");
        db.execSQL("DROP TABLE IF EXISTS goal");
        onCreate(db);
    }

    // Registers a new user
    public boolean registerUser(String username, String password) {
        if (userExists(username)) {
            return false;
        }
        // Get the database
        SQLiteDatabase db = this.getWritableDatabase();

        // Prepare the data to be inserted into the database
        ContentValues values = new ContentValues();
        values.put("username", username);
        values.put("password", password);

        // Attempt the insert
        long result = db.insert(TABLE_USERS, null, values);
        db.close(); // close the connection

        // Return the result
        return result != -1;
    }

    // Checks if a user exists
    public boolean userExists(String username) {
        // Get the database
        SQLiteDatabase db = this.getReadableDatabase();

        // Query the database by username
        Cursor cursor = db.query(TABLE_USERS, new String[]{"id"},
                "username" + "=?", new String[]{username},
                null, null, null);

        // Get the result
        boolean exists = cursor.moveToFirst();

        // Close the connection and cursor
        cursor.close();
        db.close();
        return exists; // Return the result
    }

    // Logs a user in
    public boolean loginUser(String username, String password) {
        // Get the database
        SQLiteDatabase db = this.getReadableDatabase();

        // Attempt to log the user in
        Cursor cursor = db.query(TABLE_USERS, new String[]{"id"},
                "username" + "=? AND " + "password" + "=?",
                new String[]{username, password},
                null, null, null);

        // Get the result
        boolean success = cursor.moveToFirst();

        // Close the cursor and connection
        cursor.close();
        db.close();
        return success; // Return the result
    }

    // Adds a weight record to the database
    public long addWeight(double weight, String date) {
        // Get the database
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        // Prepare the data for insertion
        values.put("weight", weight);
        values.put("date", date);

        // Attempt insertion
        long result = db.insert(TABLE_WEIGHT, null, values);

        // Close the connection
        db.close();
        return result; // Return the result
    }

    // Retrieves all the weight records from the database
    public Cursor getAllWeights() {
        // Get the database
        SQLiteDatabase db = this.getReadableDatabase();

        return db.rawQuery("SELECT * FROM " + TABLE_WEIGHT + " ORDER BY date DESC, id DESC", null);
    }

    // Gets a specific weight record by id
    public WeightRecord getWeightRecordById(int id) {
        // Open the database
        SQLiteDatabase db = this.getReadableDatabase();

        // Execute a search query by id
        Cursor cursor = db.query(TABLE_WEIGHT,
                new String[]{"id", "weight", "date"},
                "id=?", new String[]{String.valueOf(id)},
                null, null, null);
        // Create a blank record
        WeightRecord record = null;

        // Read the data into the blank record if it exists
        if (cursor.moveToFirst()) {
            double weight = cursor.getDouble(cursor.getColumnIndexOrThrow("weight"));
            String date = cursor.getString(cursor.getColumnIndexOrThrow("date"));
            record = new WeightRecord(id, weight, date);
        }

        // Close the connection
        cursor.close();
        db.close();
        return record; // Return the record
    }

    // Update a specific weight record's details
    public int updateWeight(int id, double weight, String date) {
        // Get the database
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        // Prepare the data for update
        values.put("weight", weight);
        values.put("date", date);

        // Put the updated weight and date values into ContentValues
        int rows = db.update(TABLE_WEIGHT, values, "id=?", new String[]{String.valueOf(id)});

        // Close the connection
        db.close();
        return rows; // Return the result
    }

    // Delete a weight record by id
    public int deleteWeight(int id) {
        // Get the database
        SQLiteDatabase db = this.getWritableDatabase();

        // Execute the delete query
        int rows = db.delete(TABLE_WEIGHT, "id=?", new String[]{String.valueOf(id)});

        // Close the connection
        db.close();
        return rows;
    }

    // Set or update goal weight
    public void setGoalWeight(double targetWeight) {
        // Get the database
        SQLiteDatabase db = this.getWritableDatabase();

        // Check if the goal exists
        Cursor cursor = db.rawQuery("SELECT id FROM goal LIMIT 1", null);
        ContentValues values = new ContentValues();

        // Prepare the data for insertion
        values.put("target_weight", targetWeight);

        if (cursor.moveToFirst()) {
            // Update the existing goal
            int id = cursor.getInt(cursor.getColumnIndexOrThrow("id"));
            db.update("goal", values, "id=?", new String[]{String.valueOf(id)});
        } else {
            // Insert a new goal
            db.insert("goal", null, values);
        }

        // Close the connection and DB
        cursor.close();
        db.close();
    }

    // Retrieve the goal
    public Double getGoalWeight() {
        // Get the database
        SQLiteDatabase db = this.getReadableDatabase();

        // Retrieve the goal
        Cursor cursor = db.rawQuery("SELECT target_weight FROM goal LIMIT 1", null);
        Double goalWeight = null;

        // If it exists, get the goal weight
        if (cursor.moveToFirst()) {
            goalWeight = cursor.getDouble(cursor.getColumnIndexOrThrow("target_weight"));
        }

        // Close the connectioon
        cursor.close();
        db.close();
        return goalWeight;
    }
}
