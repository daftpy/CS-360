package com.zybooks.weighttrackapp;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Calendar;

public class DetailActivity extends AppCompatActivity {
    // Declare the inputs
    EditText weightInput;
    EditText dateInput;

    Button updateButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        // Get the input fields
        weightInput = findViewById(R.id.editRecordWeightInput);
        dateInput = findViewById(R.id.editRecordDateInput);
        updateButton = findViewById(R.id.updateRecordButton);

        // Get the record id for this entry
        int recordId = getIntent().getIntExtra("RECORD_ID", -1);

        // If the record exists, display the data
        if (recordId != -1) {
            DatabaseHelper dbHelper = new DatabaseHelper(this);
            WeightRecord record = dbHelper.getWeightRecordById(recordId);

            if (record != null) {
                weightInput.setText(String.valueOf(record.getWeight()));
                dateInput.setText(String.valueOf(record.getDate()));
            }
        }

        // Set up a date picker
        dateInput.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Get the calendar
                Calendar calendar = Calendar.getInstance();

                // Get the date values
                int year = calendar.get(Calendar.YEAR);
                int month = calendar.get(Calendar.MONTH);
                int day = calendar.get(Calendar.DAY_OF_MONTH);

                DatePickerDialog dialog = new DatePickerDialog(DetailActivity.this,
                        new DatePickerDialog.OnDateSetListener() {
                            @Override
                            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                                String dateStr = (month + 1) + "/" + dayOfMonth + "/" + year;
                                dateInput.setText(dateStr);
                            }
                        }, year, month, day
                );
                dialog.show(); // Show the dialog
            }
        });

        // Set up the update button handler
        updateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String weightStr = weightInput.getText().toString().trim();
                String dateStr = dateInput.getText().toString().trim();

                // Validate inputs
                if (weightStr.isEmpty() || dateStr.isEmpty()) {
                    // TODO: both
                    return;
                }

                // Attempt to update the value
                try {
                    double weightVal = Double.parseDouble(weightStr);
                    DatabaseHelper dbHelper = new DatabaseHelper(DetailActivity.this);
                    int rows = dbHelper.updateWeight(recordId, weightVal, dateStr);
                    dbHelper.close();

                    if (rows > 0) {
                        // Successfully updated — go back to GridActivity
                        finish(); // Ends this activity and returns
                    } else {
                        // TODO: show error
                    }

                } catch (NumberFormatException e) {
                    // TODO: show error
                }
            }
        });
    }
}
