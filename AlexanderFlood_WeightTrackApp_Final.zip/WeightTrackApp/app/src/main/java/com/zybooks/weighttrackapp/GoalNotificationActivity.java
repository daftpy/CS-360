package com.zybooks.weighttrackapp;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.Toast;
import android.widget.ToggleButton;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class GoalNotificationActivity extends AppCompatActivity {
    // Declare the UI elements
    ToggleButton toggleButton;
    EditText goalInput;
    Button updateGoalButton;

    @Override
    protected void onCreate(Bundle savedInstances) {
        super.onCreate(savedInstances);
        setContentView(R.layout.activity_goal_notification);

        // Get the buttons
        toggleButton = findViewById(R.id.toggleButton);
        goalInput = findViewById(R.id.goalInput);
        updateGoalButton = findViewById(R.id.updateGoalButton);

        // Get the current goal weight
        DatabaseHelper dbHelper = new DatabaseHelper(this);
        Double goal = dbHelper.getGoalWeight();

        // If there is a goal, update the goal input
        if (goal != null) {
            goalInput.setText(String.valueOf(goal));
        }

        // Set event listener on the toggle button
        toggleButton.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                // If the toggle button is checked
                if (isChecked) {
                    if (ContextCompat.checkSelfPermission(GoalNotificationActivity.this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
                        ActivityCompat.requestPermissions(GoalNotificationActivity.this, new String[]{Manifest.permission.SEND_SMS}, 1);
                    } else {
                        Toast.makeText(GoalNotificationActivity.this, "SMS permission granted", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(GoalNotificationActivity.this, "SMS permission denied (toggle off)", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // Set the goal button event listener
        updateGoalButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Get the input value
                String goal = goalInput.getText().toString().trim();

                // If no goal weight is input, prompt the user
                if (goal.isEmpty()) {
                    Toast.makeText(GoalNotificationActivity.this, "Please enter a target weight", Toast.LENGTH_SHORT).show();
                }

                // Attempt to parse the goal weight
                double goalWeight;
                try {
                    goalWeight = Double.parseDouble(goal);
                } catch (NumberFormatException e) {
                    // On failure to parse, prompt the user
                    Toast.makeText(GoalNotificationActivity.this, "Invalid weight value", Toast.LENGTH_SHORT).show();
                    return;
                }

                // Update the goal weight in the database
                DatabaseHelper dbHelper = new DatabaseHelper(GoalNotificationActivity.this);
                dbHelper.setGoalWeight(goalWeight);
                Toast.makeText(GoalNotificationActivity.this, "Goal weight updated", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
