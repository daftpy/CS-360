package com.zybooks.weighttrackapp;

import android.Manifest;
import android.app.DatePickerDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.icu.util.ChineseCalendar;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class GridActivity extends AppCompatActivity
{
    // Declare the buttons
    Button addButton;
    Button notificationsButton;

    // Declare text
    TextView errorText;

    // Declare the inputs
    EditText weightInput;
    EditText dateInput;

    // Declare the records and adapter
    private List<WeightRecord> records;
    private WeightAdapter adapter;

    // Loads the grid layout
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_grid);

        // Get the database helper
        DatabaseHelper dbHelper = new DatabaseHelper(this);

        // Get the recycler view
        RecyclerView recyclerView = findViewById(R.id.weightRecyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Create the list
        records = new ArrayList<>();

        // Create and set the adapter for the recycler view
        adapter = new WeightAdapter(this, records);
        recyclerView.setAdapter(adapter);

        // Load the records
        loadRecords(dbHelper);

        // Get the error text
        errorText = findViewById(R.id.gridErrorText);

        // Get the input fields
        weightInput = findViewById(R.id.weightInput);
        dateInput = findViewById(R.id.dateInput);

        // Set up a date picker
        dateInput.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Get the calendar
                Calendar calendar = Calendar.getInstance();

                // Get the date values
                int year = calendar.get(Calendar.YEAR);
                int month = calendar.get(Calendar.MONTH);
                int day = calendar.get(Calendar.DAY_OF_MONTH);

                // Create a date picker dialog that will format to a string
                DatePickerDialog dialog = new DatePickerDialog(GridActivity.this,
                        new DatePickerDialog.OnDateSetListener() {
                            @Override
                            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                                // Create the date string
                                String dateStr = (month + 1) + "/" + dayOfMonth + "/" + year;

                                // Update the input
                                dateInput.setText(dateStr);
                            }
                        }, year, month, day
                );
                dialog.show(); // Show the dialog
            }
        });

        // Get the notification button and set an onClick listener
        Button notificationButton = findViewById(R.id.notificationButton);
        notificationButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(GridActivity.this, GoalNotificationActivity.class);
                startActivity(intent);
            }
        });

        // Get the add record button and set an onClick listener
        addButton = findViewById(R.id.addRecordButton);
        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Try to add the new weight record
                Double newWeight = handleAddWeight();

                // If the record was added, check the goal
                if (newWeight != null) {
                    checkGoalAndSendSMS(newWeight, dbHelper);
                }
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        DatabaseHelper dbHelper = new DatabaseHelper(this);
        loadRecords(dbHelper);
    }

    private void loadRecords(DatabaseHelper dbHelper) {
        records.clear();
        Cursor cursor = dbHelper.getAllWeights();

        while (cursor.moveToNext()) {
            int id = cursor.getInt(cursor.getColumnIndexOrThrow("id"));
            double weight = cursor.getDouble(cursor.getColumnIndexOrThrow("weight"));
            String date = cursor.getString(cursor.getColumnIndexOrThrow("date"));
            records.add(new WeightRecord(id, weight, date));
        }
        cursor.close();
        adapter.notifyDataSetChanged();
    }

    private Double handleAddWeight() {
        // Get the inputs
        String weight = weightInput.getText().toString().trim();
        String date = dateInput.getText().toString().trim();

        DatabaseHelper dbHelper = new DatabaseHelper(this);

        // Validate both values
        if (weight.isEmpty() || date.isEmpty()) {
            // Prompt for errors
            errorText.setText("You must have a weight and date value");
            return null;
        }

        // Declare weightVal and added indicator
        double weightVal;

        // Try to parse the weight value as a double
        try {
            weightVal = Double.parseDouble(weight);
        } catch (NumberFormatException e) {
            // Prompt error
            errorText.setText("You must enter a valid weight value");
            return null;
        }

        // Attempt to add the weight
        long result = dbHelper.addWeight(weightVal, date);

        // If added was successful, clear the fields
        if (result != -1) {
            errorText.setText("");
            weightInput.setText("");
            dateInput.setText("");

            loadRecords(dbHelper);
            return weightVal;
        } else {
            errorText.setText("There was an issue adding the record");
            return null;
        }
    }

    private void checkGoalAndSendSMS(double weight, DatabaseHelper dbHelper) {
        // Get the goal weight
        Double goalWeight = dbHelper.getGoalWeight();

        if (goalWeight != null && weight <= goalWeight) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
                SmsManager sms = SmsManager.getDefault();

                sms.sendTextMessage("1234567890", null,
                        "Congratulations, you hit your target goal of " + goalWeight + " lbs!",
                        null, null);
                Toast.makeText(this, "Goal reached! SMS sent.", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Goal reached, but SMS permission not granted", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
