package com.zybooks.weighttrackapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

/*
    Alexander Flood
    SNHU CS-360
    22nd June 2025
 */

public class MainActivity extends AppCompatActivity {

    // Declare the UI components
    Button loginButton;
    Button registerButton;
    EditText usernameInput;
    EditText passwordInput;

    TextView errorText;

    DatabaseHelper dbHelper;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_login);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.login), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        // Create the DB helper
        dbHelper = new DatabaseHelper(this);

        // Get the login/register buttons
        loginButton = findViewById(R.id.loginButton);
        registerButton = findViewById(R.id.registerButton);

        // Get the input fields
        usernameInput = findViewById(R.id.usernameInput);
        passwordInput = findViewById(R.id.passwordInput);

        // Get the error text
        errorText = findViewById(R.id.errorText);

        // Setup the login onclick listener
        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Get the username and password
                String username = usernameInput.getText().toString().trim();
                String password = passwordInput.getText().toString().trim();

                // Attempt login
                if (dbHelper.loginUser(username, password)) {
                    success();
                } else {
                    // Get the error text
                    errorText = findViewById(R.id.errorText);
                    // If failure, inform the user
                    errorText.setText("Invalid login");
                }
            }
        });

        registerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Get the username and password
                String username = usernameInput.getText().toString().trim();
                String password = passwordInput.getText().toString().trim();

                if (username.isEmpty()) {
                    errorText.setText("Username cannot be blank");
                }
                if (password.isEmpty()) {
                    // Prompt the user a password is required
                    errorText.setText("Password cannot be blank");
                }

                // Register the user
                boolean isRegistered = dbHelper.registerUser(username, password);

                if (isRegistered) {
                    success();
                } else {
                    errorText.setText("Registration Error. Try a new username.");
                }
            }
        });
    }

    private void success() {
        // If successful, move to grid activity
        Intent intent = new Intent(MainActivity.this, GridActivity.class);
        startActivity(intent);
    }
}