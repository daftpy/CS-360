package com.zybooks.weighttrackapp;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class WeightAdapter extends RecyclerView.Adapter<WeightAdapter.WeightViewHolder> {

    private List<WeightRecord> records;
    private Context context;

    public WeightAdapter(Context context, List<WeightRecord> records) {
        this.context = context;
        this.records = records;
    }

    @Override
    public void onBindViewHolder(WeightViewHolder holder, int position) {
        WeightRecord record = records.get(position);
        holder.weightText.setText(record.getWeight() + "lb");
        holder.dateText.setText(record.getDate());

        holder.editButton.setOnClickListener(v -> {
            // Example: Navigate to detail or show a dialog
            Intent intent = new Intent(context, DetailActivity.class);
            intent.putExtra("RECORD_ID", record.getId());
            context.startActivity(intent);
        });

        holder.deleteButton.setOnClickListener(v -> {
            DatabaseHelper dbHelper = new DatabaseHelper(context);
            int rowsDeleted = dbHelper.deleteWeight(record.getId());
            dbHelper.close();

            if (rowsDeleted > 0) {
                // Remove the item from the list and notify the adapter
                records.remove(position);
                notifyItemRemoved(position);
                notifyItemRangeChanged(position, records.size());
            }
        });
    }

    @Override
    public int getItemCount() {
        return records.size();
    }

    @Override
    public WeightViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_weight_record, parent, false);
        return new WeightViewHolder(view);
    }

    static class WeightViewHolder extends RecyclerView.ViewHolder {
        TextView weightText, dateText;
        Button editButton, deleteButton;

        public WeightViewHolder(View itemView) {
            super(itemView);
            weightText = itemView.findViewById(R.id.itemWeightText);
            dateText = itemView.findViewById(R.id.itemDateText);
            editButton = itemView.findViewById(R.id.itemEditButton);
            deleteButton = itemView.findViewById(R.id.itemDeleteButton);
        }
    }
}
