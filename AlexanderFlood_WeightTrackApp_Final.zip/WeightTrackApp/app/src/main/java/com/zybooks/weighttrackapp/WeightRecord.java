package com.zybooks.weighttrackapp;

// The WeightRecord is a class that models the records in a database
// providing an easy way to map the database data to java objects
public class WeightRecord {
    private int id;
    private double weight;
    private String date;

    // Constructor for a basic weight record
    public WeightRecord(int id, double weight, String date) {
        this.id = id;
        this.weight = weight;
        this.date = date;
    }

    public int getId() { return id; }
    public double getWeight() { return weight; }
    public String getDate() { return date; }
}
